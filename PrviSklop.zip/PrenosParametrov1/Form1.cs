﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrenosParametrov1
{
    public partial class Form1 : Form
    {
        private string ime;

        public Form1()
        {
            InitializeComponent();

            txtIme.Text = ime;
            txtPriimek.Focus();
        }

        private void btnPriimek_Click(object sender, EventArgs e)
        {
            Form2 drugaForma = new Form2();
            drugaForma.txtIme_TextChanged.Text = txtIme.Text;

            if (drugaForma.ShowDialog() == DialogResult.OK)

            txtPriimek.Text = drugaForma.txtPriimek_TextChanged.Text;
        }

        public void txtPriimek_TextChanged(object sender, EventArgs e)
        {

        }

        public void txtIme_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
