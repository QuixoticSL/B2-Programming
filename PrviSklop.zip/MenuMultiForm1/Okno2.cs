﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenuMultiForm1
{
    public partial class Okno2 : Form
    {
        public Okno2()
        {
            InitializeComponent();
        }

        private void Okno2_Load(object sender, EventArgs e)
        {
            Okno2 drugoOkno = new Okno2();

            drugoOkno.ShowDialog();
        }
    }
}
