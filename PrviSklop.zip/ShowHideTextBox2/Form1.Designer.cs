﻿namespace ShowHideTextBox2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.besedilo = new System.Windows.Forms.TextBox();
            this.Skrij = new System.Windows.Forms.Button();
            this.Pokazi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // besedilo
            // 
            this.besedilo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.besedilo.Location = new System.Drawing.Point(28, 12);
            this.besedilo.Multiline = true;
            this.besedilo.Name = "besedilo";
            this.besedilo.ReadOnly = true;
            this.besedilo.Size = new System.Drawing.Size(522, 53);
            this.besedilo.TabIndex = 0;
            this.besedilo.TabStop = false;
            this.besedilo.Text = "Tukaj se vidi besedilo, ki je napisano v text boxu.\r\nTo je druga naloga.\r\nIn to j" +
    "e tretja vrstica.";
            this.besedilo.TextChanged += new System.EventHandler(this.besedilo_TextChanged);
            // 
            // Skrij
            // 
            this.Skrij.Location = new System.Drawing.Point(267, 149);
            this.Skrij.Name = "Skrij";
            this.Skrij.Size = new System.Drawing.Size(75, 23);
            this.Skrij.TabIndex = 1;
            this.Skrij.Text = "Skrij";
            this.Skrij.UseVisualStyleBackColor = true;
            this.Skrij.Click += new System.EventHandler(this.Skrij_Click);
            // 
            // Pokazi
            // 
            this.Pokazi.Location = new System.Drawing.Point(267, 82);
            this.Pokazi.Name = "Pokazi";
            this.Pokazi.Size = new System.Drawing.Size(75, 23);
            this.Pokazi.TabIndex = 2;
            this.Pokazi.Text = "Pokazi";
            this.Pokazi.UseVisualStyleBackColor = true;
            this.Pokazi.Click += new System.EventHandler(this.Pokazi_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 341);
            this.Controls.Add(this.Pokazi);
            this.Controls.Add(this.Skrij);
            this.Controls.Add(this.besedilo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox besedilo;
        private System.Windows.Forms.Button Skrij;
        private System.Windows.Forms.Button Pokazi;
    }
}

