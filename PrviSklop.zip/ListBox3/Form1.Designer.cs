﻿namespace ListBox3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtVstavi = new System.Windows.Forms.TextBox();
            this.listSeznam = new System.Windows.Forms.ListBox();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.btnPobrisiVse = new System.Windows.Forms.Button();
            this.btnPobrisiIzbran = new System.Windows.Forms.Button();
            this.btnKonec = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtVstavi
            // 
            this.txtVstavi.Location = new System.Drawing.Point(37, 29);
            this.txtVstavi.Name = "txtVstavi";
            this.txtVstavi.Size = new System.Drawing.Size(100, 20);
            this.txtVstavi.TabIndex = 0;
            // 
            // listSeznam
            // 
            this.listSeznam.FormattingEnabled = true;
            this.listSeznam.Location = new System.Drawing.Point(37, 102);
            this.listSeznam.Name = "listSeznam";
            this.listSeznam.ScrollAlwaysVisible = true;
            this.listSeznam.Size = new System.Drawing.Size(120, 95);
            this.listSeznam.Sorted = true;
            this.listSeznam.TabIndex = 1;
            // 
            // btnDodaj
            // 
            this.btnDodaj.Location = new System.Drawing.Point(193, 40);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(75, 23);
            this.btnDodaj.TabIndex = 2;
            this.btnDodaj.Text = "&Dodaj";
            this.btnDodaj.UseVisualStyleBackColor = true;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // btnPobrisiVse
            // 
            this.btnPobrisiVse.Location = new System.Drawing.Point(193, 84);
            this.btnPobrisiVse.Name = "btnPobrisiVse";
            this.btnPobrisiVse.Size = new System.Drawing.Size(75, 23);
            this.btnPobrisiVse.TabIndex = 3;
            this.btnPobrisiVse.Text = "Pobrisi &Vse";
            this.btnPobrisiVse.UseVisualStyleBackColor = true;
            this.btnPobrisiVse.Click += new System.EventHandler(this.btnPobrisiVse_Click);
            // 
            // btnPobrisiIzbran
            // 
            this.btnPobrisiIzbran.Location = new System.Drawing.Point(193, 126);
            this.btnPobrisiIzbran.Name = "btnPobrisiIzbran";
            this.btnPobrisiIzbran.Size = new System.Drawing.Size(75, 23);
            this.btnPobrisiIzbran.TabIndex = 4;
            this.btnPobrisiIzbran.Text = "Pobrisi&Izbran";
            this.btnPobrisiIzbran.UseVisualStyleBackColor = true;
            this.btnPobrisiIzbran.Click += new System.EventHandler(this.btnPobrisiIzbran_Click);
            // 
            // btnKonec
            // 
            this.btnKonec.Location = new System.Drawing.Point(193, 166);
            this.btnKonec.Name = "btnKonec";
            this.btnKonec.Size = new System.Drawing.Size(75, 23);
            this.btnKonec.TabIndex = 5;
            this.btnKonec.Text = "&Konec";
            this.btnKonec.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 337);
            this.Controls.Add(this.btnKonec);
            this.Controls.Add(this.btnPobrisiIzbran);
            this.Controls.Add(this.btnPobrisiVse);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.listSeznam);
            this.Controls.Add(this.txtVstavi);
            this.Name = "Form1";
            this.Text = "ListBox3";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtVstavi;
        private System.Windows.Forms.ListBox listSeznam;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.Button btnPobrisiVse;
        private System.Windows.Forms.Button btnPobrisiIzbran;
        private System.Windows.Forms.Button btnKonec;
    }
}

