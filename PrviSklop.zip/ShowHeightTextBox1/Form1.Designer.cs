﻿namespace ShowHeightTextBox1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Besedilo1 = new System.Windows.Forms.TextBox();
            this.Gumb1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Besedilo1
            // 
            this.Besedilo1.Dock = System.Windows.Forms.DockStyle.Top;
            this.Besedilo1.ForeColor = System.Drawing.Color.Turquoise;
            this.Besedilo1.Location = new System.Drawing.Point(0, 0);
            this.Besedilo1.Multiline = true;
            this.Besedilo1.Name = "Besedilo1";
            this.Besedilo1.Size = new System.Drawing.Size(491, 107);
            this.Besedilo1.TabIndex = 0;
            this.Besedilo1.Text = "To je program, s katerim prikažemo osnove dela z\r\n\r\n- lastnostmi,\r\n\r\n- metodami,\r" +
    "\n\r\n- dogodki.";
            this.Besedilo1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Besedilo1.TextChanged += new System.EventHandler(this.Besedilo1_TextChanged);
            // 
            // Gumb1
            // 
            this.Gumb1.Location = new System.Drawing.Point(187, 168);
            this.Gumb1.Name = "Gumb1";
            this.Gumb1.Size = new System.Drawing.Size(110, 44);
            this.Gumb1.TabIndex = 1;
            this.Gumb1.Text = "Pokaži/Skrij";
            this.Gumb1.UseVisualStyleBackColor = true;
            this.Gumb1.Click += new System.EventHandler(this.Gumb1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 254);
            this.Controls.Add(this.Gumb1);
            this.Controls.Add(this.Besedilo1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Besedilo1;
        private System.Windows.Forms.Button Gumb1;
    }
}

