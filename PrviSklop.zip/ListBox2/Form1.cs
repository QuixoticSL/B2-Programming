﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListBox2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            if (txtVnos.Text != "") // ne vnašamo praznega niza

            {

                listSeznam.Items.Add(txtVnos.Text);

                txtVnos.Text = "";

            }

            txtVnos.Focus();
        }

        private void btnSortiraj_Click(object sender, EventArgs e)
        {
            listSeznam.Sorted = true;

            listSeznam.Sorted = false;

            txtVnos.Focus();
        }

        private void btnKonec_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
