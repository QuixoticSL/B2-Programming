﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PictureViewer
{
    public partial class Child : Form
    {
        public Child()
        {
            InitializeComponent();
        }

        internal void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)

            {

                this.Text = "Slika - " + System.IO.Path.GetFileName(openFileDialog1.FileName);

                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);

            }

            else

            {

                this.Text = "Slika";

                pictureBox1.Image = null;
            }
        }
    }
}
