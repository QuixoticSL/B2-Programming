﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabelButton1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            povrniButton.Enabled = false;
        }

        private void spremeniGumb_Click(object sender, EventArgs e)
        {
            label1.Text = "Nov napis";
            povrniButton.Enabled = true;
            spremeniGumb.Enabled = false;
        }

        private void povrniButton_Click(object sender, EventArgs e)
        {
            label1.Text = "Originalen napis";
            spremeniGumb.Enabled = true;
            povrniButton.Enabled = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Text = "Nov napis";
        }

        private void label1_MouseUp(object sender, MouseEventArgs e)
        {
            label1.Text = "Originalen napis";
        }
    }
}
