﻿namespace LabelButton1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.spremeniGumb = new System.Windows.Forms.Button();
            this.povrniButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(800, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Originalen Napis";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            this.label1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.label1_MouseUp);
            // 
            // spremeniGumb
            // 
            this.spremeniGumb.Location = new System.Drawing.Point(360, 65);
            this.spremeniGumb.Name = "spremeniGumb";
            this.spremeniGumb.Size = new System.Drawing.Size(75, 23);
            this.spremeniGumb.TabIndex = 1;
            this.spremeniGumb.Text = "Spremeni";
            this.spremeniGumb.UseVisualStyleBackColor = true;
            this.spremeniGumb.Click += new System.EventHandler(this.spremeniGumb_Click);
            // 
            // povrniButton
            // 
            this.povrniButton.Location = new System.Drawing.Point(360, 140);
            this.povrniButton.Name = "povrniButton";
            this.povrniButton.Size = new System.Drawing.Size(75, 23);
            this.povrniButton.TabIndex = 2;
            this.povrniButton.Text = "Povrni";
            this.povrniButton.UseVisualStyleBackColor = true;
            this.povrniButton.Click += new System.EventHandler(this.povrniButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.povrniButton);
            this.Controls.Add(this.spremeniGumb);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button spremeniGumb;
        private System.Windows.Forms.Button povrniButton;
    }
}

