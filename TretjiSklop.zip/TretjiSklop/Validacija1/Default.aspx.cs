﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void potrdiBtn_Click(object sender, EventArgs e) {
        Page.Validate();
        if (Page.IsValid) rezultatLabel.Text = "Obrazec je zdaj pravilno izpolnjen. Hvala.";
        else rezultatLabel.Text = "";
    }

    protected void StatusRadio_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (statusRadio.SelectedIndex == 1)
        {
            zaPlaciloTxt.Enabled = true;
            zaPlaciloRequiredFieldValidator.Enabled = true;
        }
        else
        {
            zaPlaciloTxt.Text = "";
            zaPlaciloTxt.Enabled = false;
            zaPlaciloRequiredFieldValidator.Enabled = false;
        }
    }

}