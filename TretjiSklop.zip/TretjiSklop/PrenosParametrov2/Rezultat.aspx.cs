﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Rezultat : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Request["calc


        int n1 = int.Parse(Request["TextBox1"]);
        int n2 = int.Parse(Request["TextBox2"]);
        float result = 0;
        switch (Request["calc"]) {
            case "sum":
                result = n1 + n2;
                break;
            case "multiply":
                result = n1 * n2;
                break;
            case "divide":
                result = n1 / n2;
                break;
            case "substract":
                result = n1 - n2;
                break;
            default:
                break;
        }

        lblRezultat.Text = result.ToString();
    }
}