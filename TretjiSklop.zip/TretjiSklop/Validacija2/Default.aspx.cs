﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        textBox2CompareValidator1.Enabled = false;
    }


    protected void sum_Click(object sender, EventArgs e)
    {
        string nr1 = TextBox1.Text;
        string nr2 = TextBox2.Text;

        double dnr1, dnr2;
        Page.Validate();
        if (Double.TryParse(nr1, out dnr1) && Double.TryParse(nr2, out dnr2))
        {
            Profile.rezultat = double.Parse(TextBox1.Text) + double.Parse(TextBox2.Text);
            Response.Redirect("Rezultat.aspx");
        }
        
    }

    protected void substract_Click(object sender, EventArgs e)
    {
        string nr1 = TextBox1.Text;
        string nr2 = TextBox2.Text;

        double dnr1, dnr2;
        Page.Validate();
        if (Double.TryParse(nr1, out dnr1) && Double.TryParse(nr2, out dnr2))
        {
            Profile.rezultat = double.Parse(TextBox1.Text) - double.Parse(TextBox2.Text);
            Response.Redirect("Rezultat.aspx");
        }

    }

    protected void multiply_Click(object sender, EventArgs e)
    {
        string nr1 = TextBox1.Text;
        string nr2 = TextBox2.Text;

        double dnr1, dnr2;
        Page.Validate();
        if (Double.TryParse(nr1, out dnr1) && Double.TryParse(nr2, out dnr2))
        {
            Profile.rezultat = double.Parse(TextBox1.Text) * double.Parse(TextBox2.Text);
            Response.Redirect("Rezultat.aspx");
        }
    }

    protected void divide_Click(object sender, EventArgs e)
    {
        textBox2CompareValidator1.Enabled = true;
        Page.Validate();
        if (Page.IsValid)
        {
            try
            {
                Profile.rezultat = double.Parse(TextBox1.Text) / double.Parse(TextBox2.Text);
                Response.Redirect("Rezultat.aspx");
            }
            catch { }
        }

    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
    }
}