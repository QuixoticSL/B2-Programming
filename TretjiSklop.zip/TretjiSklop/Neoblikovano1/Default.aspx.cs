﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class imeDefault : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox1.Focus();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Label1.Text = TextBox1.Text;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        Label1.Text = "";
        TextBox1.Focus();
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        if (TextBox1.Visible)
        {
            TextBox1.Visible = false;
            Label1.Visible = false;
            Label2.Visible = false;
            Button1.Visible = false;
            Button2.Visible = false;
        } else
        {
            TextBox1.Visible = true;
            Label1.Visible = true;
            Label2.Visible = true;
            Button1.Visible = true;
            Button2.Visible = true;
        }
        
    }
}