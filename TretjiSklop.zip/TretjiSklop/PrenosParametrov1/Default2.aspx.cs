﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        labelResult.Text = Request["TextBox1"] + "___" + ((DropDownList)PreviousPage.FindControl("DropDownList1")).Text + "___" + Request["mojaLabela"];

        //labelResult.Text = ((TextBox)PreviousPage.FindControl("TextBox1")).Text + "___" + ((DropDownList)PreviousPage.FindControl("DropDownList1")).Text + "___" + ((Label)PreviousPage.FindControl("Label1")).Text;


    }
}