﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string ime = Request["ime"];
        string priimek = Request["priimek"];
        string eposta = Request["posta"];
        string zaPlaciloTxt = Request["zaplacilo"];
        string letnik = Request["letnik"];
        string status = Request["status"];
        lblData.Text = "Ime: " + ime + ", priimek: " + priimek + ", eposta: " + eposta + ", zaPlacilo: " + zaPlaciloTxt + ", letnik: " + letnik + ", status: " + status;

    }
}